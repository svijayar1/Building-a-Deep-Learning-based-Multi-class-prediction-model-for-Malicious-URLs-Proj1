from openpyxl import load_workbook
from os.path import exists
import sys
import json
import whois
from datetime import datetime

def getDaysDiff(whoi_info):
 #whoi_info = json.load(whoi_info)
 if('creation_date' in whoi_info and 'expiration_date' in whoi_info):  
  if(isinstance(whoi_info['creation_date'], list) and len(whoi_info['creation_date']) > 0):
    if(whoi_info['creation_date'][0] is None or len(str(whoi_info['creation_date'][0])) == 0):
      return 1
    creationdatetime = str(whoi_info['creation_date'][0]).split()
  else:
    if(whoi_info['creation_date'] is None or len(str(whoi_info['creation_date'])) == 0):
      return 1 
    creationdatetime = str(whoi_info['creation_date']).split()
  if('-' not in creationdatetime and ':' not in creationdatetime): 
    return 1
  cDate = creationdatetime[0].split("-")
  ctime = creationdatetime[1].split(":")
  if(isinstance(whoi_info['expiration_date'], list) and len(whoi_info['expiration_date']) > 0):
    if(whoi_info['expiration_date'][0] is None or len(whoi_info['expiration_date'][0]) == 0):
      return 1
    expdatetime = str(whoi_info['expiration_date'][0]).split() 
  else:
    if(whoi_info['expiration_date'] is None or len(whoi_info['expiration_date']) == 0):
      return 1
    expdatetime = str(whoi_info['expiration_date']).split()
  if('-' not in expdatetime and ':' not in expdatetime):
    return 1   
  eDate = expdatetime[0].split("-")
  etime = expdatetime[1].split(":")  
  creationDate = datetime(int(cDate[0]), int(cDate[1]), int(cDate[2]),  int(ctime[0]), int(ctime[1]), int(ctime[2]))
  expireDate = datetime(int(eDate[0]), int(eDate[1]), int(eDate[2]),  int(etime[0]), int(etime[1]), int(etime[2]))
  print(expireDate)
  print(creationDate)
  tdiff = str(expireDate - creationDate)
  print(f'age is::{tdiff}')
  if(int(tdiff.split()[0]) < 365):
     age = 0
  else:
     age = 1 
  print('age::', age)
  return age
 else:
  return 1  


def registrantFlag(whoi_info):
  #whoi_info = json.load(whoi_info)
  if('country' in whoi_info):
   if(whoi_info['country'] is None or len(whoi_info['country']) == 0):
     return 1
   country = whoi_info['country']
   listcountries = ["CN", "VN", "ES", "RU", "KP", "FA", "WR", "HI"]
   if country in listcountries:
     flag = 0
   else:
     flag = 1  
   print('registrant country::', flag)
   return flag
  else:  
   return 1
   
   
def is_registered(domain_name):
   try:
       d = whois.whois(domain_name)
   except Exception:
       return bool(False)
   else:
       return bool(d.domain_name)   

def main():
 # total arguments
 ar = len(sys.argv)
 #print("Total arguments passed:", ar)
 if(ar == 2):
  file_exists = exists(sys.argv[1])
  if(file_exists):
   wb = load_workbook(sys.argv[1])
   #sheet = wb.worksheets[0]
   sheet = wb.active
   n = sheet.max_row
   ufcnt = int(input("Please enter number to read number of rows from file:\n"))
   if(n > ufcnt):
     n = ufcnt
   print("total rows::" , n)
   for i in range(2, n+1):
    cell_obj1 = sheet.cell(row = i, column = 1)
    cell_obj3 = sheet.cell(row = i, column = 3)
    cell_obj4 = sheet.cell(row = i, column = 4)
    print(i, "::URL::", cell_obj1.value)
    if(is_registered(cell_obj1.value)):
       whoi_info = whois.whois(cell_obj1.value)
       #print(f'url res:: {whoi_info}')
       cell_obj3.value = getDaysDiff(whoi_info)
       cell_obj4.value = registrantFlag(whoi_info)
       wb.save(sys.argv[1])
    else:
       cell_obj3.value = 0
       cell_obj4.value = 0
       wb.save(sys.argv[1])    
  else:
   print(f'The file {sys.argv[1]} does not exist')
 else:
  value = input("Please enter URL String:\n")
  print(f'You entered:{value}')
  if(is_registered(value)):
     whoi_info = whois.whois(value)
     print(f'url res:: {whoi_info}')
     age = getDaysDiff(whoi_info)
     print('age:', age)
     flag = registrantFlag(whoi_info)
     print('country category:',flag)
  else:
     age = 1
     flag = 1
     print('age:', age)
     print('country category:',flag)     
      
# Main body
if __name__ == '__main__':
    main()
